<?php

/**
 * Help links for PostgreSQL 8.2 documentation
 *
 * $Id: PostgresDoc82.php,v 1.3 2007/11/30 15:27:26 soranzo Exp $
 */

include('./help/PostgresDoc81.php');

$this->help_base = sprintf($GLOBALS['conf']['help_base'], '8.2');

?>
